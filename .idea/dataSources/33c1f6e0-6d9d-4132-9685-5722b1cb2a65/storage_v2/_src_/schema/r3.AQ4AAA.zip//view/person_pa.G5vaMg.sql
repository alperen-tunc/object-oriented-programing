create definer = root@localhost view person_pa as
select `r3`.`person`.`ID`                    AS `PERSON_ID`,
       `r3`.`person`.`VORNAME`               AS `VORNAME`,
       `r3`.`person`.`NACHNAME`              AS `NACHNAME`,
       `r3`.`personal_ausweis`.`ID`          AS `PA_ID`,
       `r3`.`personal_ausweis`.`NUMMER`      AS `NUMMER`,
       `r3`.`personal_ausweis`.`AUSGESTELLT` AS `AUSGESTELLT`,
       `r3`.`personal_ausweis`.`GÜLTIG`      AS `GÜLTIG`
from (`r3`.`person` left join `r3`.`personal_ausweis` on (`r3`.`person`.`ID` = `r3`.`personal_ausweis`.`PERSON_ID`));

