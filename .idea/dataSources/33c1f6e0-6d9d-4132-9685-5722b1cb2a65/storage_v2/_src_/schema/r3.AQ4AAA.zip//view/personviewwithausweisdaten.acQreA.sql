create definer = root@localhost view personviewwithausweisdaten as
select `r3`.`person`.`ID`               AS `ID`,
       `r3`.`person`.`VORNAME`          AS `VORNAME`,
       `r3`.`person`.`NACHNAME`         AS `NACHNAME`,
       `r3`.`person`.`GEBURTSDATUM`     AS `GEBURTSDATUM`,
       `r3`.`personal_ausweis`.`NUMMER` AS `NUMMER`,
       `r3`.`personal_ausweis`.`GÜLTIG` AS `GÜLTIG`
from (`r3`.`person` left join `r3`.`personal_ausweis` on (`r3`.`person`.`ID` = `r3`.`personal_ausweis`.`PERSON_ID`))
order by `r3`.`person`.`ID`, `r3`.`personal_ausweis`.`NUMMER`;

