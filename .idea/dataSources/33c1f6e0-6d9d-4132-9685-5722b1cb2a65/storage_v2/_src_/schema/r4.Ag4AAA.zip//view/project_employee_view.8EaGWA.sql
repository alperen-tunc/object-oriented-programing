create definer = root@localhost view project_employee_view as
select `r4`.`project`.`ID`        AS `PROJECT_ID`,
       `r4`.`project`.`NAME`      AS `NAME`,
       `r4`.`project`.`START`     AS `START`,
       `r4`.`employee`.`ID`       AS `EMPLOYEE_ID`,
       `r4`.`employee`.`VORNAME`  AS `VORNAME`,
       `r4`.`employee`.`NACHNAME` AS `NACHNAME`
from (`r4`.`project` left join (`r4`.`employee_project` left join `r4`.`employee`
                                on (`r4`.`employee`.`ID` = `r4`.`employee_project`.`EMPLOYEE_ID`))
      on (`r4`.`employee_project`.`PROJECT_ID` = `r4`.`project`.`ID`))
order by `r4`.`project`.`ID`, `r4`.`employee`.`ID`;

