create definer = root@localhost view employee_project_view as
select `r4`.`employee`.`ID`       AS `EMPLOYEE_ID`,
       `r4`.`employee`.`VORNAME`  AS `VORNAME`,
       `r4`.`employee`.`NACHNAME` AS `NACHNAME`,
       `r4`.`project`.`ID`        AS `PROJECT_ID`,
       `r4`.`project`.`NAME`      AS `NAME`,
       `r4`.`project`.`START`     AS `START`
from ((`r4`.`employee` left join `r4`.`employee_project`
       on (`r4`.`employee`.`ID` = `r4`.`employee_project`.`EMPLOYEE_ID`)) left join `r4`.`project`
      on (`r4`.`employee_project`.`PROJECT_ID` = `r4`.`project`.`ID`))
order by `r4`.`employee`.`ID`, `r4`.`project`.`ID`;

