create definer = root@localhost view person_kfz_view as
select `r2`.`person`.`ID`       AS `PERSON_ID`,
       `r2`.`person`.`VORNAME`  AS `VORNAME`,
       `r2`.`person`.`NACHNAME` AS `NACHNAME`,
       `r2`.`kfz`.`ID`          AS `KFZ_ID`,
       `r2`.`kfz`.`HERSTELLER`  AS `HERSTELLER`,
       `r2`.`kfz`.`MODELL`      AS `MODELL`
from (`r2`.`person` left join `r2`.`kfz` on (`r2`.`person`.`ID` = `r2`.`kfz`.`PERSON_ID`))
order by `r2`.`person`.`ID`;

